var json = require('./apertureLabsClocks.json');

const util = require('util');

var fs = require("fs");
console.log("\n *START* \n");
var content = fs.readFileSync('./apertureLabsClocks.json');
fs.closeSync(2);
var jsonContent = JSON.parse(content);

var clockslength = jsonContent.clocks.length;
var employeeslength = jsonContent.employees.length;
var clocks = jsonContent.clocks;
var employees = jsonContent.employees;

//Setup

// employee = {
//  	//Has id, first_name, last_name	
//  		labour: [ 
//  		//has elements

//  			elements = {
//  			//has date, total and object array		
//  				labour_by_time_period: {
//  				//period array	
//  			}

//  		 }	
 		
//  		]
//  	}


var employeeReport = [];
var EmplyeeObj = {};
var labour = [];
var elements={};
var labour_by_time_period = {};
//If someone worked more than 24hours
var labour_by_time_period0 = {};




var calReport = function(id){
for(var i=0; i<clockslength; i++){


	if(clocks[i].employee_id == id){
		EmplyeeObj.employee_id = employees[id].id;
		EmplyeeObj.first_name = employees[id].first_name;
		EmplyeeObj.last_name = employees[id].last_name;


		var startDate = clocks[i].clock_in_datetime + "Z";
		var endDate = clocks[i].clock_out_datetime + "Z";
		var sd =  new Date(startDate);
		var ed   = new Date(endDate);
		var day = sd.getUTCDate();
		var month = sd.getMonth() + 1;
		var year = sd.getFullYear();
		var date = day + "-" + month + "-" + year;
		//elements.date = date;
		var hoursWorkedInMs = ed.getTime() - sd.getTime();
		var total = hoursWorkedInMs / 3600000;
		
		var clockInHour = sd.getUTCHours();
		var clockInMin = sd.getMinutes();
		var clockInSecs = sd.getSeconds();

		var clockOutHour = ed.getUTCHours();
		var clockOutMin = ed.getMinutes();
		var clockOutSecs = ed.getSeconds();
		
		elements.total = total;
		elements.date = date;


		if(total > 24 ){
			labour_by_time_period0.period1 = 7;
			labour_by_time_period0.period2 = 6;
			labour_by_time_period0.period3 = 5;
			labour_by_time_period0.period4 = 6;
			elements.labour_by_time_period0 = labour_by_time_period0;			
			day = day+1;
			var newdate = day + "-" + month + "-" + year; 
			elements.date0 = newdate;
		}
		
		if(clockInHour > 5 && clockInHour <= 12) {
			var HourSpentInPeriodOne = 12 - clockInHour;
			var MinSpentInPeriodOne = clockInMin;
			var SecSpentInPeriodOne = clockInSecs; 
			var hoursSpent = HourSpentInPeriodOne - (MinSpentInPeriodOne/60) - (SecSpentInPeriodOne/3600);
			labour_by_time_period.period1 = hoursSpent;

			if(clockOutHour <= 12) {
				elements.labour_by_time_period= labour_by_time_period; 
			}
			if(clockOutHour > 12 && clockOutHour <= 18 ){
				var remainingHours = clockOutHour - 12;
				var numOfHours = remainingHours + (clockOutMin/60) + (clockOutSecs/3600);
				labour_by_time_period.period2 = numOfHours;
				elements.labour_by_time_period = labour_by_time_period;
				//console.log(labour_by_time_period);
			}
			if(clockOutHour > 18 && clockOutHour <= 23 ){
				labour_by_time_period.period2 = 6;
				var remainingHours = clockOutHour - 18;
				labour_by_time_period.period3 = remainingHours + (clockOutMin/60) + (clockOutSecs/3600);
				elements.labour_by_time_period = labour_by_time_period;
			}
			if(clockOutHour > 23 && clockOutHour <= 5 ){
				labour_by_time_period.period2 = 6;
				labour_by_time_period.period3 = 5;
				if(clockOutHour > 23 ){
				var remainingHours = clockOutHour - 23;
				labour_by_time_period.period4 = remainingHours + (clockOutMin/60) + (clockOutSecs/3600);
				elements.labour_by_time_period4 = labour_by_time_period;

				} 
			}
				else if(clockOutHour <=5 ){
				var remainingHours = clockOutHour + 1 
				labour_by_time_period.period4 = remainingHours + (clockOutMin/60) + (clockOutSecs/3600);
				elements.labour_by_time_period4 = labour_by_time_period;
			}

		} else if(clockInHour > 12 && clockInHour <= 18 ){
			var HourSpent = 18 - clockInHour;
			var MinSpent = clockInMin;
			var SecSpent = clockInSecs; 
			var hoursSpent = HourSpent - (MinSpent/60) - (SecSpent/3600);
			labour_by_time_period.period2 = hoursSpent;
			
			if(clockOutHour <=18 ){
			elements.labour_by_time_period= labour_by_time_period; 
			}
			if(clockOutHour > 18 && clockOutHour <= 23 ){
				var remainingHours = clockOutHour - 18;
				labour_by_time_period.period3 = remainingHours + (clockOutMin/60) + (clockOutSecs/3600);
				elements.labour_by_time_period = labour_by_time_period;
			}
			if(clockOutHour > 23 || clockOutHour <= 5){
				labour_by_time_period.period3 = 5;
				if(clockOutHour > 23){				
				var remainingHours = clockOutHour - 23;
				labour_by_time_period.period4 = remainingHours + (clockOutMin/60) + (clockOutSecs/3600);
				elements.labour_by_time_period = labour_by_time_period;
				}else if (clockOutHour <= 5) {
					var remainingHours = clockOutHour + 1; //Because I want Count 00:00 -01: 00
					labour_by_time_period.period4 = remainingHours + (clockOutMin/60) + (clockOutSecs/3600);
					elements.labour_by_time_period= labour_by_time_period; 
				} 
			}

		}else if(clockInHour > 18 && clockInHour <= 23) {
			var HourSpentInPeriodOne = 23 - clockInHour;
			console.log(clockInHour);
			var MinSpent = clockInMin;
			var SecSpent = clockInSecs; 
			var hoursSpent = HourSpentInPeriodOne - (MinSpent/60) - (SecSpent/3600);
			labour_by_time_period.period3 = hoursSpent;
			elements.labour_by_time_period= labour_by_time_period; 
			//console.log(clockOutHour);

			if(clockOutHour <=23){
				elements.labour_by_time_period= labour_by_time_period; 
			}

			if(clockOutHour > 23 || clockOutHour <= 5 ) {
				if(clockOutHour>23){
					var remainingHours = clockOutHour - 23;
					labour_by_time_period.period4 = remainingHours + (clockOutMin/60) + (clockOutSecs/3600);
					elements.labour_by_time_period= labour_by_time_period; 
			}else if(clockOutHour>= 0 && clockOutHour<= 5){ 
					var remainingHours = clockOutHour + 1;
					labour_by_time_period.period4 = remainingHours + (clockOutMin/60) + (clockOutSecs/3600);
					elements.labour_by_time_period= labour_by_time_period; 
				}
			}
			if(clockOutHour > 5 && clockOutHour <= 12 ){
				labour_by_time_period.period4 = 6;
				var remainingHours = clockOutHour - 5;
				var numOfHours = remainingHours + (clockOutMin/60) + (clockOutSecs/3600);
				labour_by_time_period.period1 = numOfHours;
				elements.labour_by_time_period = labour_by_time_period;
			}
			if(clockOutHour > 12 && clockOutHour <= 18 ){
				labour_by_time_period.period1 = 7;
				var remainingHours = clockOutHour - 12;
				labour_by_time_period.period2 = remainingHours + (clockOutMin/60) + (clockOutSecs/3600);
				elements.labour_by_time_period = labour_by_time_period;
			}
			
		} else if (clockInHour > 23 || clockInHour<=5) {
			//Assuming Shift is definetely more than an hour after clock in 
			var HourSpent = 5 - clockInHour + 1 ;
			var MinSpent = clockInMin;
			var SecSpent = clockInSecs; 
			var hoursSpent = HourSpent - (MinSpent/60) - (SecSpent/3600);
			labour_by_time_period.period4 = hoursSpent; 

			if(clockOutHour <= 5) {
				elements.labour_by_time_period= labour_by_time_period; 
			}
			if(clockOutHour> 5 && clockOutHour <= 12 ){
				var remainingHours = clockOutHour - 5;
				var numOfHours = remainingHours + (clockOutMin/60) + (clockOutSecs/3600);
				labour_by_time_period.period1 = numOfHours;
				elements.labour_by_time_period = labour_by_time_period;

			}if(clockOutHour > 12 && clockOutHour <= 18){
				labour_by_time_period.period1 = 7;
				var remainingHours = clockOutHour - 12;
				labour_by_time_period.period2 = remainingHours + (clockOutMin/60) + (clockOutSecs/3600);
				elements.labour_by_time_period = labour_by_time_period;

			}if(clockOutHour > 18 && clockOutHour <= 23){
				labour_by_time_period.period1 = 7;
				labour_by_time_period.period2 = 5;
				var remainingHours = clockOutHour - 18;
				labour_by_time_period.period3 = remainingHours + (clockOutMin/60) + (clockOutSecs/3600);
				elements.labour_by_time_period = labour_by_time_period;
			}
		}


	
		} 
		

	}

		labour.push(elements);

		EmplyeeObj.labour = labour;

		employeeReport.push(EmplyeeObj);
		console.log(util.inspect(employeeReport, {showHidden: false, depth: null}));
		
		return employeeReport;
		
	
}


var generateEmployeeReport = calReport(0); //Calculates Report based on id
var convertToJson = JSON.stringify(generateEmployeeReport, null, 2);

fs.writeFileSync('./return.json', convertToJson , 'utf-8');
