There are 4 files in zip folder other than Readme.txt. 

index.js -> Contains a big function that takes in id and returns an employee report. The function handles all employee except employee 1. This is due the fact that I have done a lot of hard coding. I did not want to take too much time implementing it as I have deadline. I understand the problem fully and in great detail. I can definitely solve this issue given more time. 

return.json -> this is the file where the output report is saved. Currently, it has a dummy output for employee_id 1. However its not correct.  

labour_hours.json -> All the outputs returned by the function i.e. employee id 0,2 and 3. 

